!/usr/bin/bash

# some useful commands for monitoring linux

# measuring disk usage
du -h
du -sh

# measuring disk space
df -h .
du -h

# checking files
diff file01  file02
comm file01 file02

# top: about all the running processes on the Linux machine
top

# ps: process status

# Display the current user's processes
ps

# Display all processes running on the system
ps -e

# Display detailed information about running processes
ps -ef

# Display processes owned by the specified user
ps -u frankvp

# Display processes owned by the specified user
ps –aux
