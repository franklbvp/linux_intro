!/usr/bin/bash

# wc no options: shows (number of lines) (number of words)  (number of bytes)
wc english.txt  file03
echo "====="

# wc show the number of lines
ls | wc -l 
echo "====="

# wc number of words
wc -w file03
cat file03 | wc -w
echo "====="

