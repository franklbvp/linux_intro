#!/usr/bin/bash

# merge the rows into a line with  delimiter ','
cat file03
paste -s -d',' file03

# merge the rows 2 by 2 into a line with  delimiter ','
paste -d':' - -  < file03

# merge the rows 2 by 2 into a line with  delimiter ','
paste -d':' file01 file02
