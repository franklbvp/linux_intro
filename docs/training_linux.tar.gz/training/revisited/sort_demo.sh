#!/usr/bin/bash

# sort without options = lexicographic sort
cat file01 | sort

# sort -n = numeric sort
cat file01 | sort -n

# sort -r  reverse order
cat file01 | sort -r

# sort randomly
cat file01 | sort -R

# combine files and sort
cat file01 file02 file03 | sort

