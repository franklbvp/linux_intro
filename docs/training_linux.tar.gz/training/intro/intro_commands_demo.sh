#!/usr/bin/bash


echo $SHELL

whoami

hostname

pwd

date
