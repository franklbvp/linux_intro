#!/usr/bin/bash


# use cat to show content of file
cat lorem_test.txt

# show more files concatenated
cat hello.c  lines.txt

# use a viewer
more lines.txt

# use a better viewer - less is more
less lines.txt

# view top part
head lines.txt

head -25 lines.txt

#view bottom part
tail lines.txt

tail -25 lines.txt
 
