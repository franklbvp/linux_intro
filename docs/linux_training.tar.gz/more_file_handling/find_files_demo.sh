#!/usr/bin/bash


# look in the currect directory for files starting with table
find . -name "bla*"
ls "bla*"
ls -R | grep 'bla.*'


# find the directories starting with dir
find . -type d -name "dir*"


# find the files with permission 777
find ~ -type f -perm 0777

# find empty directories
find . -type d -empty

# get some information on a file
file matstats.log
stat matstats.log

# differences
diff table.txt  table_bis.txt
