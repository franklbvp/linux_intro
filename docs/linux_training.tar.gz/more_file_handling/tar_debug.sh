#!/usr/bin/bash

# simple debugger mode 
# https://selivan.github.io/2022/05/21/bash-debug.html
# 
# this code enables a primitive debug mode
# run the script with bash script_name.sh
function _trap_DEBUG() {
    echo "# $BASH_COMMAND";
    while read -r -e -p "debug> " _command; do
        if [ -n "$_command" ]; then
            eval "$_command";
        else
            break;
        fi;
    done
}
trap '_trap_DEBUG' DEBUG

# basic tar command - tar archive of current directory
tar -cvf my_archive.tar .
ls

# check tar
tar -tf my_archive.tar
less my_archive.tar

# compress the tar file
gzip my_archive.tar


# unpacking things - first unzip
gunzip my_archive.tar.gz

# untar in a different directory
mkdir backup
tar -xvf my_archive.tar -C ./backup

# extract a specific file from tar
mkdir backup2
tar -xvf my_archive.tar ./hello.c 