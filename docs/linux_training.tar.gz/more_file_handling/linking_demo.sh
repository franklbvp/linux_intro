#!/usr/bin/bash

# symbolic link demo

# create link to hello.c
ln -s hello.c link2hello


# use the link
less link2hello

# rename the original file and check the link
mv hello.c hello_bis.c
less link2hello
mv hello_bis.c  hello.c

# link to a directory
ln -s dir5/subdir1  fastlinksubdir51
cd fastlinksubsir51
# check the path
pwd
pwd -P
