#!/usr/bin/bash


# show the information
ls -al


chmod 666 table.dat

ls -al

chmod o-w table.dat

ls -al
