#!/usr/bin/bash

# simple debugger mode 
# https://selivan.github.io/2022/05/21/bash-debug.html
# 
# this code enables a primitive debug mode
# run the script with bash script_name.sh
function _trap_DEBUG() {
    echo "# $BASH_COMMAND";
    while read -r -e -p "debug> " _command; do
        if [ -n "$_command" ]; then
            eval "$_command";
        else
            break;
        fi;
    done
}
trap '_trap_DEBUG' DEBUG

# look in the currect directory for files starting with table
find . -name "bla*"
ls "bla*"
ls -R | grep 'bla.*'


# find the directories starting with dir
find . -type d -name "dir*"


# find the files with permission 777
find ~ -type f -perm 0777

# find empty directories
find . -type d -empty

# get some information on a file
file matstats.log
stat matstats.log

# differences
diff table.txt  table_bis.txt