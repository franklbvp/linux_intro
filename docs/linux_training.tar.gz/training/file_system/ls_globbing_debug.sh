#!/usr/bin/bash

# simple debugger mode 
# https://selivan.github.io/2022/05/21/bash-debug.html
# 
# this code enables a primitive debug mode
# run the script with bash script_name.sh
function _trap_DEBUG() {
    echo "# $BASH_COMMAND";
    while read -r -e -p "debug> " _command; do
        if [ -n "$_command" ]; then
            eval "$_command";
        else
            break;
        fi;
    done
}
trap '_trap_DEBUG' DEBUG

# starting with host
ls -l /etc/host*

# extension allow or deny
ls -l /etc/hosts.{allow,deny} 	

# extension not starting with a
ls -l /etc/hosts.[!a]* 	

# starting with host and 1 character
ls -l /etc/host? 