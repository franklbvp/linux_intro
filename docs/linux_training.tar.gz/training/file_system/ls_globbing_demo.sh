#!/usr/bin/bash

# starting with host
ls -l /etc/host*

# extension allow or deny
ls -l /etc/hosts.{allow,deny} 	

# extension not starting with a
ls -l /etc/hosts.[!a]* 	

# starting with host and 1 character
ls -l /etc/host? 
