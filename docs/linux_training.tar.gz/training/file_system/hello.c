/* 
Hello World program 
*/

#include<stdio.h>

int main()
{
   printf("Hello World \n");   // print statement
   printf("Hello World \n");
   printf("Hello World \n");
   printf("Hello World \n");
   printf("Hello World \n");
   printf("Hello World \n");
   printf("Hello World \n");
   return 0;
}
