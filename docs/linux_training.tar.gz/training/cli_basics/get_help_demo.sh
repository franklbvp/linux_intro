#!/usr/bin/bash

# getting help  pt1

ls --help

ls -h


# getting help pt2
man ls


# getting help pt3
info ls


# getting help
whatis ls
whereis ls
help ls
type ls


