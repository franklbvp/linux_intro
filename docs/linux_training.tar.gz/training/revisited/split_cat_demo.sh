!/usr/bin/bash

# split
split -n 5 shakespeare_sonnet.txt sonnet
echo "====="

# glue the parts back
cat sonnet* > shakespeare_back 
echo "====="
