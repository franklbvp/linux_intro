#!/usr/bin/bash

# split large file in 3 parts
split -n 3 t8.shakespeare.txt  t8.shakespeare.part.

# split a file based on size
split -b 100k t8.shakespeare.txt   t8.shakespeare.partsize.
