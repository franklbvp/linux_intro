!/usr/bin/bash

# tr casting
echo "My Demo String" | tr "abcdefghijklmnopqrstuvwxyz" "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
echo "====="

# tr remove blancs redirect result to file
tr -d " " < english.txt >noblanc.txt
echo "====="

# tr caesar cipher
cat english.txt | tr 'a-z' 'e-zabcd' > secret.txt
echo "====="

