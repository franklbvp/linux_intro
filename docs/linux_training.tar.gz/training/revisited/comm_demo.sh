#!/usr/bin/bash

# comm
comm codes01  codes02

# comm using sorted files
comm <(sort -n codes01)  <(sort -n codes02)
