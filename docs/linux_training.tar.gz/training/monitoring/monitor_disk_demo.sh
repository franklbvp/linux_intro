!/usr/bin/bash

# some useful commands for monitoring linux

# measuring disk usage best to specify the directory
du ~/training

# get the information in human readable format
du -h  ~/training

# get the sum 
du -sh ~/training

# the all option 
du -ah ~/training

# info with last modification 
du -h --time ~/training


# specify the depth  (sum up for deeper nested branches)
du -d 2 ~ 


# measuring disk space
df -ah
df -ah ~/training

