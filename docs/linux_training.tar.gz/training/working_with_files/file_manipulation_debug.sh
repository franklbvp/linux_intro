#!/usr/bin/bash

# simple debugger mode 
# https://selivan.github.io/2022/05/21/bash-debug.html
# 
# this code enables a primitive debug mode
# run the script with bash script_name.sh
function _trap_DEBUG() {
    echo "# $BASH_COMMAND";
    while read -r -e -p "debug> " _command; do
        if [ -n "$_command" ]; then
            eval "$_command";
        else
            break;
        fi;
    done
}
trap '_trap_DEBUG' DEBUG

# mkdir
mkdir newdir01

mkdir -v newdir02/subdir01

mkdir -pv newdir02/subdir01


# rmdir only removes empty directories
pwd
cd newdir01
ls
cd ..
rmdir newdir01

# copy files
ls
cp lines.txt newdir02
cp lines.txt newdir02/subdir02


# cp options
cp -iv lorem_test.txt  newdir02

# cp a directory use the recursive option
mkdir newdir01
cp -rv newdir02  newdir01

# mv move or rename
mv lines.txt lines_new.txt
ls lin*
mv lines_new.txt lines.txt

mv newdir01 newdir03

# rm remove files - be careful
cd newdir02
ls
rm -iv lines.txt
cd ..

# tip use the ls command first with the same options to check the selection of files
ls -r newdir03
rm -rv newdir03
rm newdir02
rm -rv newdir02
