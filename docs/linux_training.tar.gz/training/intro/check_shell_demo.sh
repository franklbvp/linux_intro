#!/usr/bin/bash


echo $SHELL
