#!/usr/bin/bash


# basic tar command - tar archive of current directory
tar -cvf my_archive.tar .
ls

# check tar
tar -tf my_archive.tar
less my_archive.tar

# compress the tar file
gzip my_archive.tar


# unpacking things - first unzip
gunzip my_archive.tar.gz

# untar in a different directory
mkdir backup
tar -xvf my_archive.tar -C ./backup

# extract a specific file from tar
mkdir backup2
tar -xvf my_archive.tar ./hello.c 
