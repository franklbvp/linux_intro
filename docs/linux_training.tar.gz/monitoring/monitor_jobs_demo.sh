!/usr/bin/bash

# some useful commands for monitoring linux
#  lauch
# nano &   (launched in the backgraound)
# sleep 1000  &  

# nano &
# sleep 1000 &

# use command jobs
# jobs

# jobs -l

# ps

# use fg and bg command

# fg 1

# bg 1

# stop execution with ctrl-z