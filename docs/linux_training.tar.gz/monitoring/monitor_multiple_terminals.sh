!/usr/bin/bash

# show different processes and jobs
# open windows terminal
# launch nano, sleep 1000 in background

# open terminal in MobaXterm
# launch evince & 
# launch xclock &

# show command ps in both terminals

# ps -aux

