#/usr/bin/bash

# log the output of the top command

top -bn 6 > top.log
