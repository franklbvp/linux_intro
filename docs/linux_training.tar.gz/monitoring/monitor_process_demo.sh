!/usr/bin/bash

# some useful commands for monitoring linux


# top: about all the running processes on the Linux machine
top

# htop: more elaborated top
htop

# ps: process status

# Display the current user's processes
ps

# Display all processes running on the system
ps -e

# Display detailed information about running processes
ps -ef

# Display processes owned by the specified user
ps -u frankvp

# Display processes owned by the specified user
ps –aux
