#/usr/bin/bash

# command substitution
# copy the ls file

which ls

# the classic way of working
cp -v /usr/bin/ls .

# a smarter way ?!
cp -v $(which ls) .

