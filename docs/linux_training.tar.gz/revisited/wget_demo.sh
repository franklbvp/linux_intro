#!/usr/bin/bash


# get a file from the web
wget -v  https://github.com/franklbvp/linuxintro/raw/master/docs/WSL-short_intro.pdf

wget -v  https://github.com/franklbvp/linuxintro/raw/master/docs/linux_training.tar.gz

