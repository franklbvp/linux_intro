!/usr/bin/bash

# uniq
uniq file01
echo "====="

# uniq after sorting input file
cat file01 | sort | uniq > file01_uniq
echo "====="
