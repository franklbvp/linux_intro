#!/usr/bin/bash

# a first example using variables
greet='hello'
name='world'
echo $greet $name
