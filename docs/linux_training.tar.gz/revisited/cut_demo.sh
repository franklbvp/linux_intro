#!/usr/bin/bash


# cut take a csv file use the delimiter , and keep the fields(columns) 1 and 3
cut -d',' -f 1,3 ape_00.csv > ape_mashup_01

# keep the first 5 characters
cut -c 1-5 ape_00.csv > ape_mashup_02

# use a different output delimiter
cut -d',' -f 2-5 --output-delimiter='&' ape_00.csv  > ape_mashup_03
