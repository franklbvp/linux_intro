#!/usr/bin/bash

# different timing examples 
time ls
echo "====="

time ping kuleuven.be
echo "====="

time sleep 3
echo "====="

