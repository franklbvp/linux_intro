#/usr/bin/bash

# pipe examples


# redirect from screen output to file (create a new file)
ls  > less 

# compare  redirection with a pipe
ls | less

# search in the history file
history | grep update


