#!/usr/bin/bash

# simple debugger mode 
# https://selivan.github.io/2022/05/21/bash-debug.html
# 
# this code enables a primitive debug mode
# run the script with bash script_name.sh
function _trap_DEBUG() {
    echo "# $BASH_COMMAND";
    while read -r -e -p "debug> " _command; do
        if [ -n "$_command" ]; then
            eval "$_command";
        else
            break;
        fi;
    done
}
trap '_trap_DEBUG' DEBUG

# use cat to show content of file
cat lorem_test.txt

# show more files concatenated
cat hello.c  lines.txt

# use a viewer
more lines.txt

# use a better viewer - less is more
less lines.txt

# view top part
head lines.txt

head -25 lines.txt

#view bottom part
tail lines.txt

tail -25 lines.txt
 