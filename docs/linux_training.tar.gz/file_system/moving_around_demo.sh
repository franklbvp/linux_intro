#!/usr/bin/bash

# where am i
pwd

# go to directory dir1
cd dir1
pwd

# move up 1 level (parent)
cd ..
pwd

# go to root
cd / 
pwd

# move back to home
ls
cd home
ls
