#!/usr/bin/bash

# starting with host
ls -l /etc/host*
echo " "

# extension allow or deny
ls -l /etc/hosts.{allow,deny}
echo " "

# extension not starting with a
ls -l /etc/hosts.[!a]*
echo " "

# starting with host and 1 character
ls -l /etc/host? 
echo " "
