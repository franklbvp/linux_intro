#/usr/bin/bash

# redirect examples


# redirect from screen output to file (create a new file)
ls  > ls_out.txt

# append redirect from screen output to file
ls -l >> ls_out.txt

# input redirection
sort < ls_out.txt

# play with error stream
ls non-existing*
ls non-existing*  > ls_err.txt
ls non-existing*  2> ls_err.txt


# works also with top
# -b batch mode
# -n number of repetitions
top -bn 5 > top.log


