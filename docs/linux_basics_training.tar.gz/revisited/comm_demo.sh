#!/usr/bin/bash

# comm on file01 and file02 - warning not sorted!
comm file01 file02

# sort files and use comm
sort < file01 > file01_sort
sort < file02 > file02_sort
comm file01_sort file02_sort
comm file01_sort file01_sort

