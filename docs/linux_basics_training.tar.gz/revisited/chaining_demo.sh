!/usr/bin/bash

#  chain commands
mkdir dir101; mkdir dir102

mkdir dir101 && echo 'mkdir was successful'

mkdir dir101 || echo 'mkdir was not successful'


# use your own code
./hello_return0 && echo "hello world succesfully  ended"


