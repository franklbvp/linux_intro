#/usr/bin/bash

# use bc
# read an input file
# use -l to increase the precision of the result
bc -l < bc_input.txt


