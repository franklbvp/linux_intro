#!/usr/bin/bash

# some useful applicetions of grep
# based on  https://www.thegeekstuff.com/2009/03/15-practical-unix-grep-command-examples/

# Search for the given string in a single file
cat file01
grep this file01
grep 1  file01

# Checking for the given string in multiple files.
grep 1 fil*


# Case insensitive search using grep -i
grep -i ZZ *

# Match regular expression in files
# searches for all the pattern that starts with “KAT” and ends with "a" 
# with anything in-between
grep KAT.*a *

# Checking for full words, not for sub-strings using grep -w
grep with t8*
grep -w with t8*


# Searching in all files recursively using grep -r
# look for the string “11” in all the files in the current directory 
# and all it’s subdirectory.
grep -r "11"

# Counting the number of matches using grep -c
grep -rc "11"

# Display only the file names which matches the given pattern using grep -l
grep -lr "11"

# search in the history file for a command
history | grep update

# list the directories in the cuurent folder
ls -l | grep ^d
