#!/usr/bin/bash

# weak quoting - variable expansion

echo "Path to your shell is: $SHELL,$(ls)"

# strong quoting - no expansion

echo 'Path to your shell is: $SHELL,$(ls)'


