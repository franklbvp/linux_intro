#!/usr/bin/bash


# check the path
pwd

# diff between 2 files
diff helloc  hellocd 

