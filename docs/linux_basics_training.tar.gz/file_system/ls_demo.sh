#!/usr/bin/bash


# all
ls -a

# long list
ls -l

# time
ls -t

# size
ls -S 

# reverse
ls -r

# combining options long timme reversed (oldest on top)
ls -ltr

# using wildcards
ls *txt

# file type  / directory * executable
ls -F
